export const productList2 =[
    {'title': 'Sony ICDBX140 Portable Digital Recorder', 'category': 'communication'}, {'title': 'Sony ICDPX470 Portable Digital Recorder', 'category': 'communication'}, {'title': 'Olympus DM-720 Voice Recorder', 'category': 'communication'}, {'title': 'Olympus OLMWS852 Portable Digital Recorder', 'category': 'communication'}, {'title': 'Sangean DPR76 Digital Receiver', 'category': 'communication'}, {'title': 'Olympus VN-541PC Portable Digital Recorder', 'category': 'communication'}, {'title': 'Philips DVT2110 Portable Digital Recorder', 'category': 'communication'}, {'title': 'Philips DVT4010 Portable Digital Recorder', 'category': 'communication'}, {'title': 'Zoom Q8 Handy Portable Digital Recorder', 'category': 'communication'}, {'title': 'Philips DVT8110 Portable Digital Recorder', 'category': 'communication'}, {'title': 'Philips DVT4110 Portable Digital Recorder', 'category': 'communication'}, {'title': 'Philips DVT6110 Portable Digital Recorder', 'category': 'communication'}, {'title': " Amazon Best Seller's", 'category': 'communication'}, {'title': ' Tascam DR-05X Tascam 05X Stereo Handheld Digital Audio Recorder with USB Audio Interface', 'category': 'communication'}, {'title': ' Zoom Q2n-4K Handy Video Recorder, 4K/30P Ultra High Definition Video, Compact Size, Stereo Microphones, Wide Angle Lens, for Recording Music, Video, YouTube Videos, Livestreaming', 'category': 'communication'}, {'title': ' Samson 29/GTRACKPRO Samson USB Mic with Instrument Input and Mixer and Monitoring', 'category': 'communication'}, {'title': ' Panasonic - DMR-HWT260GL - Smart Network 1TB HDD Recorder', 'category': 'communication'}, {'title': ' Olympus LS-P1 Digital Voice Recorder', 'category': 'communication'}, {'title': ' 8GB Flash Drive U Disk Digital Audio Recorder Memory Storage Portable Voice Recorder for Home Office School Travel (Black)', 'category': 'communication'}, {'title': ' Focusrite Scarlett 2i2 3rd Gen USB Audio Interface', 'category': 'communication'}, {'title': ' Hnsat 8GB Keychains Audio Digital Voice Recorder USB Flash Drive Black - UR-08', 'category': 'communication'}, {'title': ' Mackie Big Knob Studio+ 4x3 Studio Monitor Controller and Interface', 'category': 'communication'}, {'title': ' 8GB Mini LCD USB Digital Rechargeable Audio Voice Recorder Recording Device AU', 'category': 'communication'}, {'title': ' Hnsat Digital Voice-Activated Voice Recorder Dual Microphone HD Stereo Recording - DVR-616', 'category': 'communication'}, {'title': ' Hnsat Mini Professional 8GB Digital Voice Recorder with Belt Clip Black - WR-16', 'category': 'communication'}, {'title': ' Voice Recorder Forensics Pen Professional Smart Noise', 'category': 'communication'}, {'title': ' Apogee Jam+ USB Instrument Interface', 'category': 'communication'}, {'title': ' Novation Launchkey 49 Mk3 49-key Keyboard Controller USB MIDI Controller', 'category': 'communication'}, {'title': " Find a better deal on your NBN with Getprice's new broadband comparison tools", 'category': 'communication'}, {'title': ' Mackie MDB-1A Active Direct Box 1-channel Active Direct Box with -20dB Pad', 'category': 'communication'}, {'title': ' Mackie MDB-USB Stereo USB Direct Box with Ground Lift, and Balanced XLR Outputs', 'category': 'communication'}, {'title': ' Mackie MDB-1P 1-Channel Passive Direct Box', 'category': 'communication'}, {'title': " Mackie Performance Pack PROFX6 2 x Dynamic Mic's MC-150 Headphones", 'category': 'communication'}, {'title': ' Radial ProD8 8-channel Passive Instrument Direct Box with custom Transformers', 'category': 'communication'}, {'title': ' TC-Helicon GO GUITAR PRO Portable Interface for Mobile Devices GoGuitarPro', 'category': 'communication'}, {'title': ' Philips DVT1150 4BGB Digital Voice Recorder Activated Audio Tracer Notes/Ideas', 'category': 'communication'}, {'title': ' Philips VoiceTracer Audio Voice Recorder for Interviews w/ 2 Microphone Black', 'category': 'communication'}, {'title': ' Philips VoiceTracer Meeting/Voice Recorder w/ Built In Memory/Card Slot Silver', 'category': 'communication'}, {'title': ' Philips DVT7110 8GB VoiceTracer Audio Recorder w/3 Mics/DSLR Video Shooting Kit', 'category': 'communication'}, {'title': ' Sony BX140 MP3 4GB Digital Voice IC Recorder - Sliver', 'category': 'communication'}, {'title': ' TASCAM DR-05X Stereo Handheld Recorder 2-channel Handheld Recorder', 'category': 'communication'}, {'title': ' Digital Voice Recorder Wrist Watch', 'category': 'communication'}, {'title': ' Novation Launchpad Mini mk3 Grid Controller for Ableton Live USB MIDI Controller', 'category': 'communication'}, {'title': ' Focusrite Scarlett Solo Studio Interface 3rd Gen Recording Bundle', 'category': 'communication'}, {'title': ' Philips Dragon NS - SR Software Exclusive to DVT Range', 'category': 'communication'}, {'title': ' Philips VoiceTracer 8GB Audio Recorder (DVT2050)', 'category': 'communication'}, {'title': ' E-Lektron Podcast USB Condenser Microphone with Pop filter stand and sound card', 'category': 'communication'}, {'title': ' Join our 72-hour Birthday treasure hunt for special offers now.', 'category': 'communication'}, {'title': ' Focusrite Scarlett 4i4 3rd Gen USB Recording Interface', 'category': 'communication'}, {'title': ' Focusrite Scarlett 8i6 3rd Gen USB Audio Interface', 'category': 'communication'}, {'title': ' Focusrite Scarlett 18i20 3rd Gen USB Audio Interface', 'category': 'communication'}, {'title': ' UR-09 USB Flash Drive Digital Voice Recorder', 'category': 'communication'}, {'title': ' 1pc Speaker Protective Case Portable Carrying Box', 'category': 'communication'}, {'title': ' RME Babyface Pro FS 24-channel USB Audio Interface 12-in/12-out Bus-powered', 'category': 'communication'}, {'title': ' 2pcs 6.35mm Audio Microphone Guitar Speaker Plug Key Chains', 'category': 'communication'}, {'title': ' Focusrite Scarlett 18i8 3rd Gen USB Audio Interface', 'category': 'communication'}, {'title': ' 1Pc Digital Voice Recorder U Disk Recorder Sound Recorder', 'category': 'communication'}, {'title': ' 20pcs Pretty Lovely Practical Cupcake Picks Dessert Toppers', 'category': 'communication'}, {'title': ' Portable Keychain Digital Voice Recorder MP3 Player Sound Audio Recorder I9H5', 'category': 'communication'}, {'title': ' Conference 3.5mm Microphone Omnidirectional Mic 360 Degree', 'category': 'communication'}, {'title': ' USB Mini Voice Recorder Digital Record 8GB Small Audio Recording MP3 Player Z1I4', 'category': 'communication'}, {'title': ' Tascam DR-10L Digital Audio Recorder with Lapel Microphone', 'category': 'communication'}, {'title': ' Hnsat Wearable Wristband Digital Voice Recorder 4GB USB One Button Record - WR-06', 'category': 'communication'}, {'title': ' Hnsat Mini 8GB Memory USB Flash Drive Digital Audio Voice Recorder - UR-09-8GB', 'category': 'communication'}, {'title': ' Hnsat Mini 4GB Memory USB Flash Drive Digital Audio Voice Recorder - UR-09-4GB', 'category': 'communication'}, {'title': ' Hnsat 8GB Bluetooth Digital Voice Recorder Phone Call Recorder Rec/TF - DVR-188', 'category': 'communication'}, {'title': ' E-Lektron EL422T 2-Channel USB Audio Interface 24Bit/48kHz Class-A Pre-Amp Phantom 20dB additional headroom', 'category': 'communication'}, {'title': ' E-Lektron AIM-42 4-channel streaming audio mixer mixer incl. USB audio interface sound card', 'category': 'communication'}, {'title': ' Novation Launchkey 25 Mk3 25-key Keyboard Controller', 'category': 'communication'}, {'title': ' Mackie Onyx Producer 2-2 USB Audio Interface 2-in-2-out USB 2.0 ONYX-PROD-2-2', 'category': 'communication'}, {'title': ' Mackie M48 Phantom Power Supply +48v with XLR Input and Output', 'category': 'communication'}, {'title': ' Mackie Creation Pack condensor Mic CR3 studio Monitors MC150 Headphones', 'category': 'communication'}, {'title': ' Mackie Performance Bundle Onyx Interface condesor & vocal mic with Headphones', 'category': 'communication'}, {'title': ' Awaretech Power Bank Charging Station with Built-In Audio Voice Recorder MQ-L500', 'category': 'communication'}, {'title': ' Awaretech Mini USB Flash Drive with Built-In Audio Voice Recorder MQ-U350', 'category': 'communication'}, {'title': ' Mackie Onyx Artist 1-2 USB Audio Interface 2-in/2-out USB 2.0 Audio Interface', 'category': 'communication'}, {'title': ' Olympus VP-20 Digital Voice Recorder', 'category': 'communication'}, {'title': ' Tascam DR-07X 2-Channel PCM Linear Handheld Recorder', 'category': 'communication'}, {'title': ' Tascam DR-05X 2-Channel Linear PCM Recorder', 'category': 'communication'}, {'title': ' WS853 OLYMPUS 8Gb Digital True Stereo Mp3 Vr Slide Out USB With Micro SD True Stereo Microphones 8GB DIGITAL TRUE STEREO MP3 VR', 'category': 'communication'}, {'title': ' Olympus LS-P4 Music & Voice Recorder (8GB)', 'category': 'communication'}, {'title': ' SK-868 8GB Portable USB Disk Audio Voice Recorder for Interview Lecture AU', 'category': 'communication'}, {'title': ' Apogee Groove USB DAC and Headphone Amp for Mac & Windows', 'category': 'communication'}, {'title': ' RME Fireface UCX USB / FireWire Interface 18-channel Hybrid USB Interface', 'category': 'communication'}, {'title': ' Tascam DR-10L-W Digital Audio Recorder with Lapel Microphone White', 'category': 'communication'}, {'title': ' Awaretech Pen with In-Built Microphone Audio and Voice Recorder MQ-99 8GB', 'category': 'communication'}, {'title': ' Focusrite Scarlett 2i2 Studio 3rd Gen Recording Bundle', 'category': 'communication'}, {'title': ' Digital Voice Recorder,Voice Activated Recorder for Lectures,Meetings,Voice Activated Recorder Digital Audio Recorder Mini Dictaphone with MP3 Player', 'category': 'communication'}, {'title': ' Behringer PODCASTUDIO 2 USB Bundle - Podcasting Bundle Xenyx 302USB Mixer, Ultravoice XM8500 Dynamic Vocal Microphone', 'category': 'communication'}, {'title': ' Apogee Element 88 - 16x16 Thunderbolt Audio Interface for Mac', 'category': 'communication'}, {'title': ' Philips 8GB Stereo Recording With Battery', 'category': 'communication'}, {'title': ' Rechargeable Digital USB Audio Sound Voice Recorder Dictaphone Mini MP3 Player', 'category': 'communication'}, {'title': ' Philips VoiceTracer Audio/Voice Recorder for Music/Lectures w/ 3 Microphone Grey', 'category': 'communication'}, {'title': ' Philips 2 MIC Stereo 8GB In-Built Battery FM Radio Audio Voice Recorder Silver', 'category': 'communication'}, {'title': ' Hnsat 8GB Sport Watch Voice Recorder with 6 Modes & Password Protection - WR-19-8GB', 'category': 'communication'}, {'title': ' Olympus AS-2400 Transcription Kit', 'category': 'communication'}, {'title': ' Olympus AS-9000 Professional Transcription Kit', 'category': 'communication'}, {'title': ' Olympus DS-9000 Digital Voice Recorder', 'category': 'communication'}, {'title': ' Olympus DS-9500 Digital Voice Recorder', 'category': 'communication'}, {'title': ' Xiaomi Black Shark Audio DAC & Quick Charge 2-in-1 Adapter - Black', 'category': 'communication'}, {'title': ' Hnsat Stylish 4GB Mini Heart Keychain Voice Recorder Pendant Voice Recorder - WR03-4GB', 'category': 'communication'}, {'title': ' Hnsat 16GB Sport Watch Voice Recorder with 6 Modes & Password Protection - WR-19-16GB', 'category': 'communication'}, {'title': ' Hnsat WR02 Stylish 8GB Mini Heart Keychain Voice Recorder Pendant Voice Recorder - WR-02-8GB', 'category': 'communication'}, {'title': ' Hnsat Voice Recorder 8GB Mini USB Flash Digital Audio Voice Recording - UR-26-8GB', 'category': 'communication'}, {'title': ' Hnsat 8GB USB Disk Digital Audio Voice Recorder MP3 Player Recorder One Button + Long Time Recording - UR-12', 'category': 'communication'}, {'title': ' Hnsat 8GB Digital Voice Recorder Bracelet Recording Watch 1536Kbps Black - WR-18A', 'category': 'communication'}, {'title': ' Hnsat 8GB Digital Voice Recorder Bracelet Recording Watch 1536Kbps Black - WR-18', 'category': 'communication'}, {'title': ' Hnsat 1080P Night Vision USB Video Camera 180 Degree Rotate Voice Recorder with Motion Detection and Loop Recording - UC-30', 'category': 'communication'}, {'title': ' Hnsat DVR-166 FM Professional Digital Voice Recorder with FM Radio 8GB Recorder - DVR-166FM', 'category': 'communication'}, {'title': ' Hnsat 8GB USB Flash Digital Voice Recorder with MP3 Function Silver - DVR-126', 'category': 'communication'}, {'title': ' Behringer S16 16-channel Digital Snake with Remote-controllable Mic Pres', 'category': 'communication'}, {'title': ' Hnsat Wearable Wristband Digital Voice Recorder 8GB USB One Button Record - WR-06', 'category': 'communication'}, {'title': ' Hnsat 8GB Voice Recorder Sound HD Recording Player With OLED Display - DVR-626', 'category': 'communication'}, {'title': ' Philips VoiceTracer Audio/Voice Recorder for Lectures w/ 3 Microphone Silver', 'category': 'communication'}, {'title': ' 1 Pc Watch Protector Watch Protective Cover Watch Case', 'category': 'communication'}, {'title': ' Solid State Logic SSL2 2x2 USB Audio Interface - 2-in/2-out', 'category': 'communication'}, {'title': ' 30pcs Pretty Practical Chic New Year Decors Spiral Ornaments', 'category': 'communication'}, {'title': ' RME Digiface AVB 128 IN x128 OUT AVB/USB 3.0 Audio Interface', 'category': 'communication'}, {'title': ' RME Digiface Dante 128-in/128-out Dante/MADI/USB 3.0 Audio Interface', 'category': 'communication'}, {'title': ' RME Digiface USB Portable Digital Audio Interface 32-in/32-out', 'category': 'communication'}, {'title': ' 8GB SPY Digital Voice Recorder Pen Dictaphone USB Memory', 'category': 'communication'}, {'title': ' Pocket-sized 2-in-1 8GB USB Flash Drive Digital USB Audio', 'category': 'communication'}, {'title': ' 1Pc Durable Lightweight Portable Stave Tool Drawing Tool for', 'category': 'communication'}, {'title': ' Philips VoiceTracer 8GB Audio Recorder with Speech Recognition Software (DVT2810)', 'category': 'communication'}, {'title': ' Philips 4GB Recording Voice Tracer Digital Recorder (DVT1150)', 'category': 'communication'}, {'title': ' Philips 24bit/96kHz 3MIC APP Control & Share', 'category': 'communication'}, {'title': ' 1pc Speaker Silicone Protective Case Compatible for', 'category': 'communication'}, {'title': ' Mini Professional Recording Pen No Memory Noise Reduction', 'category': 'communication'}, {'title': ' Behringer U-Phoria UMC1820 USB Audio Interface USB 2.0 Audio Interface, 18-in/20-out', 'category': 'communication'}, {'title': ' Q60 High Definition Noise Reduction Voice Control USB MP3 Recording Pen, 8G', 'category': 'communication'}, {'title': ' Q60 High Definition Noise Reduction Voice Control USB MP3 Recording Pen, 4G', 'category': 'communication'}, {'title': ' Q33 External Play MP3 Voice Control High Definition Noise Reduction Recording Pen, 32G, Support Password Protection & One-touch Recording', 'category': 'communication'}, {'title': ' Q33 External Play MP3 Voice Control High Definition Noise Reduction Recording Pen, 4G, Support Password Protection & One-touch Recording', 'category': 'communication'}, {'title': ' Q33 External Play MP3 Voice Control High Definition Noise Reduction Recording Pen, 16G, Support Password Protection & One-touch Recording', 'category': 'communication'}, {'title': ' K603 Mini Monochrome LCD Handheld Voice Recorder, 8G, Support TF Card', 'category': 'communication'}, {'title': ' C181 1080P Mini Back Clip 130 Degree Small Wide Angle Meeting Lecture Professional Video Recorder Pen', 'category': 'communication'}, {'title': ' Digital Voice Recorder MP3 Player with 4GB Memory', 'category': 'communication'}, {'title': ' 1 Pc Watch Protector Protective Watch Case Watch Accessories', 'category': 'communication'}, {'title': ' 1 Set 4GB Digital Voice Recorder Professional Recording Pen', 'category': 'communication'}, {'title': ' 8GB Digital Voice Recorder Voice Activated Recorder MP3 Player 1536Kbps HD G6W6', 'category': 'communication'}, {'title': ' Olympus WS-852 4GB Digital Voice Recorder Silver', 'category': 'communication'}, {'title': ' Olympus VN-541PC 4GB Black Digital Voice Recorder inc Battery & microUSB Cable', 'category': 'communication'}, {'title': ' Mini Digital Voice Audio Recorder Dictaphone USB Disk for', 'category': 'communication'}, {'title': ' Zoom H6 Black Handy Portable Digital Audio Field Recorder Interchangeable Mics', 'category': 'communication'}, {'title': ' Zoom H4n PRO Handy 4 Track Channel Portable Digital Audio Field Recorder Black', 'category': 'communication'}, {'title': ' Zoom H2n Handy Portable Digital Audio Field Recorder', 'category': 'communication'}, {'title': ' Zoom H2n Portable Digital Audio Recorder(FXR002)', 'category': 'communication'}, {'title': ' Tascam DP-32SD 32 Track Digital Portastudio DP32 DP32SD - Porta Studio - BNIB', 'category': 'communication'}, {'title': ' Tascam DP-006 Portable 6 Track Digital Portastudio DP006 - BNIB - Belfield Music', 'category': 'communication'}, {'title': ' New Zoom H2n Next Gen Ultra PortableDigital Recorder', 'category': 'communication'}, {'title': ' Zoom H6 Black Portable 6 Track digital Multi Track Audio Recorder Podcast 24 bit', 'category': 'communication'}, {'title': ' Tascam DP-008EX 8 Track Digital Portastudio DP008EX Porta Studio Recorder - BNIB', 'category': 'communication'}, {'title': ' Zoom H1n Handheld PCM Portable Field Audio Sound Recorder w/ XY Mixrophones', 'category': 'communication'}, {'title': ' Zoom H6 All Black Digital Recorder', 'category': 'communication'}, {'title': ' NEW Portable Mini Mic Digital Stereo Microphone for Recorder Mobile Phone', 'category': 'communication'}, {'title': ' Portable Digital Audio Voice Recorder Pen Sound Activated Recording Pen 16GB AU', 'category': 'communication'}, {'title': ' 100pcs Novelty Compact Brushes Mesh Covers Brushes Protectiv', 'category': 'communication'}, {'title': ' Philips DVT2805 VoiceTracer Speech Recognition Software for Audio/Voice Recorder', 'category': 'communication'}, {'title': 'Apple AirTag Tracker', 'category': 'mobile-phone-accessories'}, {'title': 'Tile Mate Bluetooth Tracker', 'category': 'mobile-phone-accessories'}, {'title': 'DJI Osmo Mobile 3', 'category': 'mobile-phone-accessories'}, {'title': 'Tile Slim Bluetooth Tracker', 'category': 'mobile-phone-accessories'}, {'title': ' SIM-only mobile plans', 'category': 'mobile-phone-accessories'}, {'title': ' Heavy Duty Shockproof Case Cover For Samsung Galaxy S3 - Black', 'category': 'mobile-phone-accessories'}, {'title': ' Samsung Galaxy Note 20 Ultra (6.9") 5G OTTERBOX Commuter Slim Rugged Case - Black', 'category': 'mobile-phone-accessories'}, {'title': ' CASEMATE Tough Groove Case For Google Pixel 4A (5.8") - Iridescent', 'category': 'mobile-phone-accessories'}, {'title': ' iPhone 12 Mini (5.4") OTTERBOX Defender XT Rugged Case with MagSafe - Black', 'category': 'mobile-phone-accessories'}, {'title': ' iPhone 11 Pro Max (6.5") Otterbox Otter + Pop Symmetry Case - Black', 'category': 'mobile-phone-accessories'}, {'title': ' iPad Pro 12.9 (5th/2021) UAG [U] Lucent Translucent Lightweight Smart Folio Case - Black', 'category': 'mobile-phone-accessories'}, {'title': ' iPad Pro 11 (3rd/2021) UAG Scout Slim Heavy-Duty Case (Req. Smart Keyboard)', 'category': 'mobile-phone-accessories'}, {'title': ' MOPHIE USB-C PD Wall Adapter 20W - White', 'category': 'mobile-phone-accessories'}, {'title': ' iPad Mini (5th/4th Gen) GRIFFIN Survivor Endurance Rugged Case Modular - Black', 'category': 'mobile-phone-accessories'}, {'title': ' Apple Watch (44mm-42mm) RINGKE Metal One Stainless Steel Band - Black', 'category': 'mobile-phone-accessories'}, {'title': ' Samsung Galaxy A12 Soft Clear Case - Clear', 'category': 'mobile-phone-accessories'}, {'title': ' Lenovo Tab P11 (11") FLEXII GRAVITY Pirate Rugged Case - Black', 'category': 'mobile-phone-accessories'}, {'title': ' SAMSUNG Galaxy Z Fold 3 5G Leather Flip Cover - Black', 'category': 'mobile-phone-accessories'}, {'title': ' BELKIN UNIVERSAL CAR VENT MOUNT FOR iPHONE / SAMSUNG GALAXY / LG / SMARTPHONES UPTO 5.5 INCH', 'category': 'mobile-phone-accessories'}, {'title': ' Samsung Galaxy A32 5G RINGKE Fusion X Rugged Case - Black', 'category': 'mobile-phone-accessories'}, {'title': ' SURFACE PRO 7+/7/6/5/4/3 INCIPIO ORD PROTECTIVE PADDED SLEEVE - PURPLE', 'category': 'mobile-phone-accessories'}, {'title': ' LG Nexus 5X Ringke Fusion Sleek Impact case - Smoke Black/Clear', 'category': 'mobile-phone-accessories'}, {'title': ' Samsung Galaxy S6 Tech21 Evo Check Case - Smokey/Black', 'category': 'mobile-phone-accessories'}, {'title': ' Samsung Galaxy Tab S3 9.7 Inch Incipio Faraday Hard Shell Folio Case - Black', 'category': 'mobile-phone-accessories'}, {'title': ' JACK SPADE NEW YORK COLORBLOCK DIPPED CANVAS SLEEVE FOR MACBOOK 13 INCH - BURGUNDY/NAVY', 'category': 'mobile-phone-accessories'}, {'title': ' JACKERY NOMAD 150 WIRELESS POWER BANK CHARGER PAD', 'category': 'mobile-phone-accessories'}, {'title': ' IPHONE XR MOPHIE JUICE PACK ACCESS 2000 mAH BATTERY CASE - BLACK', 'category': 'mobile-phone-accessories'}, {'title': ' SAMSUNG Travel Adapter 25W USB-C Super Fast Wall Charger - White', 'category': 'mobile-phone-accessories'}, {'title': ' iPhone 12 Pro / 12 (6.1") GRIFFIN Survivor Extreme Case - Black', 'category': 'mobile-phone-accessories'}, {'title': ' iPhone 11 (6.1") Otterbox Otter + Pop Symmetry Case - Mauvelous', 'category': 'mobile-phone-accessories'}, {'title': ' iPhone 12 Pro Max (6.7") SPECK Presidio Perfect-Clear with Grips Case - Clear', 'category': 'mobile-phone-accessories'}, {'title': ' Oppo A52 EFM Zurich Armour Rugged Case - Clear', 'category': 'mobile-phone-accessories'}, {'title': ' BELKIN Boost Charge PRO 3-in-1 Wireless Charger with MagSafe 15W - Black', 'category': 'mobile-phone-accessories'}, {'title': ' Oppo A15 ITSKINS Spectrum Rugged Slim Case - Light Pink', 'category': 'mobile-phone-accessories'}, {'title': ' SAMSUNG Smart S-View Wallet Cover For Galaxy A72 - Black', 'category': 'mobile-phone-accessories'}, {'title': ' iPhone 11 (6.1") Otterbox Otter + Pop Symmetry Case - Black', 'category': 'mobile-phone-accessories'}, {'title': ' MACBOOK PRO 15 INCH (USB-C) INCASE TEXTURED HARDSHELL IN WOOLENEX CASE - BLUSH PINK', 'category': 'mobile-phone-accessories'}, {'title': ' iPad Pro 11 (2nd Gen/1st Gen) UAG Metropolis Slim Rugged Slim Folio Case - Black', 'category': 'mobile-phone-accessories'}, {'title': ' iPhone SE (2nd Gen)/7/8 - Otterbox Defender Rugged Case - Black', 'category': 'mobile-phone-accessories'}, {'title': ' Samsung Galaxy S20 (FE) 5G PANZERGLASS Screen Protector', 'category': 'mobile-phone-accessories'}, {'title': ' LG K61 ITSKINS Spectrum Clear Rugged Slim Case - Transparent', 'category': 'mobile-phone-accessories'}, {'title': ' MacBook Pro 16 UAG Plyo Feather light Rugged Military Case - Ice', 'category': 'mobile-phone-accessories'}, {'title': ' Oppo Reno 10X Zoom FLEXII GRAVITY Silcone Gel TPU Case - Clear', 'category': 'mobile-phone-accessories'}, {'title': ' Galaxy Z Flip 3 5G UAG Civilian Rugged Case - Mallard', 'category': 'mobile-phone-accessories'}, {'title': ' BELKIN BoostCharge 20W USB-C PD Wall Charger - White', 'category': 'mobile-phone-accessories'}, {'title': ' iPhone SE (2nd Gen)/8/7 TECH21 Pure Clear Rugged Slim Case - Clear', 'category': 'mobile-phone-accessories'}, {'title': ' OTTERBOX Fast Charge Qi Wireless Power Bank 10000 mAh 18W USB-PD - Black', 'category': 'mobile-phone-accessories'}, {'title': ' iPad Air (4th Gen -10.9") OTTERBOX Defender Rugged Case - Black', 'category': 'mobile-phone-accessories'}, {'title': ' iPhone 13 Pro Max (6.7") Tech21 Evo Clear Rugged Case W/Magsafe - Clear', 'category': 'mobile-phone-accessories'}, {'title': ' iPhone 11 Pro Max (6.5") Otterbox Symmetry Clear Case - Clear', 'category': 'mobile-phone-accessories'}, {'title': ' APPLE WATCH SERIES 6/SE/5/4 (44MM) CATALYST WATERPROOF CASE - BLACK', 'category': 'mobile-phone-accessories'}, {'title': ' Samsung Galaxy S20 Plus (6.7") UAG Monarch Handcrafted Rugged Case - Carbon Fiber', 'category': 'mobile-phone-accessories'}, {'title': ' iPHONE 8 PLUS/7 PLUS TECH21 EVO WALLET FLEXSHOCK FOLIO CASE - BLACK', 'category': 'mobile-phone-accessories'}, {'title': ' MICROSOFT SURFACE GO 2 & GO INCIPIO CAPTURE ULTRA RUGGED CASE WITH ROTATING HAND STRAP - BLACK', 'category': 'mobile-phone-accessories'}, {'title': ' iPhone 11 (6.1") GRIFFIN Survivor Endurance Case - Black/Citrus/Clear', 'category': 'mobile-phone-accessories'}, {'title': ' iPad Pro 11 (3rd Gen) SPECK Balance Folio Rugged Case - Black', 'category': 'mobile-phone-accessories'}, {'title': ' iPad Pro 12.9 (5th Gen) SPECK Balance Folio Rugged Case - Black', 'category': 'mobile-phone-accessories'}, {'title': ' OTTERBOX USB-C 30W Fast Charge Wall Charger - Black Shimmer', 'category': 'mobile-phone-accessories'}, {'title': ' OTTERBOX USB-C 50W GAN Fast Charge Dual Port Wall Charger - Black Shimmer', 'category': 'mobile-phone-accessories'}, {'title': " iPad 10.2 (9th/8th/7th Gen) OTTERBOX Kids' Easy Grab Rugged Case - Martian", 'category': 'mobile-phone-accessories'}, ]

    export const categoryData =  {  
        "Computers" : [
            'all-computers',		
            'laptops', 
            'printers',
            'tablet',
            'monitors',
            'desktops',
            'hardware',
            'Components',
            'Networking',
            'Software',
            // Components

            // Networking
            
            // Software
            
        ],
        "TVs": [
            'all-television',
            'televisions',
            'projectors',
            'blu-ray-players',
            'media-streaming-devices',
            'tv-and-video',
        ],
        "Audio":  [
            'all-audio',
            'head-phones',
            'speakers',
            'portable-speakers',
            'radio-players',
            'amplifiers-receivers',
            'home-audio',
            'portable-digital-recorders',
            'portable-cd-players', 
            'mp3-media-players',
            'mp3-media-players-accessories',
            'audio-video-accessories',
            'studio-and-stage-equipment',
            'audio-visual-cables',
            'audio-visual-equipment',           
        ],
    
        "Smart Home": [
            'all-security',
            'security-systems-and-surveillance',
            'home-automation',
            'remote-controls',  
            'home-security',
            'gps-devices',
        ],
    
    
        "Mobile Phone & Accessories" : [
            "all-phones",
            'mobile-phones',
            'smart-watches',
            'mobile-phone-accessories',
            'two-way-radios',
            'phones',
        ],
    
        "Gaming" : [
            'all-gaming',
            'pc-games',
            'game-consoles',
            'xbox-one-games',
            'game-accessories',
            'ps4-playstation-4-games',
            'video-game-consoles',
        ],
    
        "Music Vinyl" : [
            'all-movies-and-vinyl',
            'misc-music',
            'rock-music',
            'vinyl-records',
            'self-help-relaxation-music',
            'pop-music',
            'music',
            'misc-movies',
            'comedy-movies',
            'dvd-pack',
            'television-series',
            'western-movies',
            'movies',
        ],
    
        "Movies, TV Shows & Music Vinyl": [
            'western-movies',
            'comedy-movies',
            'dvd-pack',
            'television-series',
            'movies',
            'misc-music',
            'rock-music',
            'vinyl-records',
            'self-help-relaxation-music',
            'pop-music',
            'music',
            'misc-movies',
            
        ],
    
        // "Collectibles & Merchandise": [
        //     "All Collectibles and Merchandise",
        //     "New Arrivals",
        //     "Hot Deals & Offers",
        //     "POP! Vinyl",
        //     "Collectibles",
        //     "Merchandise",
        //     "Shop by franchise",
        //     "Apparel",
        //     "Card & board games",
        //     "Jigsaw puzzles",
        // ],
        "Cameras & Drones": [
            'digital-cameras',
            'camera-accessories',
            'camera-lenses',
            'camcorders',
            'drones',
            'cameras-camcorders',
        ],
    
    
        // "Drones, escooters & Tech Toys" : [
        //     "All Drones", 
        //     "E-scooters and Tech Toys",
        //     "Drones",
        //     "E-scooters & rideables",
        //     "Robotics & tech toys",
    
        // ],
    
        // "Health & Fitness Wearables" : [
        //     "All Health, Fitness & Wearables",
        //     "Smart watches",
        //     "Sports watches",
        //     "Activity trackers",
        //     "Wearables",
        //     "Health & grooming",
        // ],
        "Fridges, Freezers and Dishwashers": [
            'all-Fridges-freezers-and-dishwashers',
            'refrigerators',
            'freezers',
            'dishwashers'
        ],
        "Washing Machines and Dryers" : [
            'all-Washing-machines-and-dryers',
            'washing-machines',
            'dryers',
        ],
        "Home Accessories" : [
            'refrigerators',
            'vacuums',
            'washing-machines',
            'dishwashers',
            'air-conditioners',
            'home-appliances',
            'coffee-makers',
            'blenders-mixers',
            'kettles',
            'toasters',
            'food-processors',
            'small-kitchen-appliances',
            'irons',
        ],
        "Heating & Cooling" : [
            'home-heater-systems',
            'heaters',
            'air-conditioners',
            'refrigerators',
        ]
    }



    export const subCategoryData =  {  
        'all-computers': []
        ,
        'laptops': [
            "Macbooks",
            "Notebooks",
            "Gaming Laptops"
        ], 
        'printers': [
            "Canon Printers",
            "Epson Printers",
            "Printers under $600",
        ],
        'tablet': [
            "IPads",
            "Windows Tablets",
            "Android Tablets"
        ],
        'monitors': [
            "28 Inch Monitors",
            "32 Inch Monitors",
            "38 Inch Monitors"
        ],
        'desktops': [
            "Desktops under $600",
            "Desktops in $600-$1200",
            "Apple Desktops",
            "Windows Desktops"
        ],
        'hardware': [

        ],
        'Components': [

        ],
        'Networking': [

        ],
        'Software': [
            
        ],

            'all-television': [

            ],
            'televisions': [

            ],
            'projectors': [

            ],
            'blu-ray-players': [

            ],
            'media-streaming-devices': [

            ],
            'tv-and-video': [

            ],

            'all-audio': [

            ],
            'head-phones': [

            ],
            'speakers': [

            ],
            'portable-speakers': [

            ],
            'radio-players': [

            ],
            'amplifiers-receivers': [

            ],
            'home-audio': [

            ],
            'portable-digital-recorders': [

            ],
            'portable-cd-players': [

            ], 
            'mp3-media-players': [

            ],
            'mp3-media-players-accessories': [

            ],
            'audio-video-accessories': [

            ],
            'studio-and-stage-equipment': [

            ],
            'audio-visual-cables': [

            ],
            'audio-visual-equipment': [

            ],
            'all-security': [

            ],
            'security-systems-and-surveillance': [

            ],
            'home-automation': [

            ],
            'remote-controls': [

            ],  
            'home-security': [

            ],
            'gps-devices': [

            ],
            'all-phones': [

            ],
            'mobile-phones': [

            ],
            'smart-watches': [

            ],
            'mobile-phone-accessories': [

            ],
            'two-way-radios': [

            ],
            'phones': [

            ],
            'all-gaming': [

            ],
            'pc-games': [

            ],
            'game-consoles': [

            ],
            'xbox-one-games': [

            ],
            'game-accessories': [

            ],
            'ps4-playstation-4-games': [

            ],
            'video-game-consoles': [

            ],
            'all-movies-and-vinyl': [

            ],
            'misc-music': [

            ],
            'rock-music': [

            ],
            'vinyl-records': [

            ],
            'self-help-relaxation-music': [

            ],
            'pop-music': [

            ],
            'music': [

            ],
            'misc-movies': [

            ],
            'comedy-movies': [

            ],
            'dvd-pack': [

            ],
            'television-series': [

            ],
            'western-movies': [

            ],
            'movies': [

            ],

            'digital-cameras': [

            ],
            'camera-accessories': [

            ],
            'camera-lenses': [

            ],
            'camcorders': [

            ],
            'drones': [

            ],
            'cameras-camcorders': [

            ],
            'all-Fridges-freezers-and-dishwashers': [

            ],
            'refrigerators': [

            ],
            'freezers': [

            ],
            'dishwashers': [

            ],
            'all-Washing-machines-and-dryers': [

            ],
            'washing-machines': [

            ],
            'dryers': [

            ],
            'refrigerators': [

            ],
            'vacuums': [

            ],
            'washing-machines': [

            ],
            'dishwashers': [

            ],
            'air-conditioners': [

            ],
            'home-appliances': [

            ],
            'coffee-makers': [

            ],
            'blenders-mixers': [

            ],
            'kettles': [

            ],
            'toasters': [

            ],
            'food-processors': [

            ],
            'small-kitchen-appliances': [

            ],
            'irons': [

            ],
            'home-heater-systems': [

            ],
            'heaters': [

            ],
            'air-conditioners': [

            ],
            'refrigerators': [

            ],

    }

